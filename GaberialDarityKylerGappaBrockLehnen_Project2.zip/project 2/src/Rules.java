public class Rules {
    /*
        Wumpus -> Stench(X,Y+1)
                  -Wumpus(X,Y) || Stench(X,Y-1)
        Pit -> Breeze(X-1,Y-1) || Breeze(X,Y+1)
                -Pit(X,Y) || Breeze(X-1,Y+1)
     */
}
